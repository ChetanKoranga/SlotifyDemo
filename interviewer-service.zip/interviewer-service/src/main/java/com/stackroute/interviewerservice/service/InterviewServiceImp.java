package com.stackroute.interviewerservice.service;

import com.stackroute.interviewerservice.model.InterviewerEntity;
import com.stackroute.interviewerservice.reprository.InterviewRepository;
import org.springframework.stereotype.Service;

@Service
public class InterviewServiceImp implements InterviewService{
    private InterviewRepository interviewRepository;
    @Override
    public InterviewerEntity createInterview(InterviewerEntity interviewerEntity) {
        return interviewRepository.save(interviewerEntity);
    }

    /*@Override
    public InterviewerEntity updateInterview(InterviewerEntity interviewerEntity) {
        return null;
    }*/
}
