package com.stackroute.interviewerservice.service;

import com.stackroute.interviewerservice.model.InterviewerEntity;

public interface InterviewService {
     InterviewerEntity createInterview(InterviewerEntity interviewerEntity);
    /* InterviewerEntity updateInterview(InterviewerEntity interviewerEntity);*/
}
