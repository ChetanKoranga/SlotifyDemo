package com.stackroute.interviewerservice.reprository;

import com.stackroute.interviewerservice.model.InterviewerEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InterviewRepository extends MongoRepository <InterviewerEntity,String>{

}
