package com.stackroute.interviewerservice.controller;

import com.stackroute.interviewerservice.model.InterviewerEntity;
import com.stackroute.interviewerservice.service.InterviewService;
import com.stackroute.interviewerservice.service.InterviewServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")


public class InterviewController {
    @Autowired
    private InterviewService interviewservice;

    @PostMapping("/UpdateAvailability")
    public InterviewerEntity saveInterview(@RequestBody InterviewerEntity interviewerEntity){
        return interviewservice.createInterview(interviewerEntity);
    }
   /*@GetMapping
    public String Demo(){
        return "hello";
    }*/



}
